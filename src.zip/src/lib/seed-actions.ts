'use server';

import { Timestamp, FieldValue } from 'firebase-admin/firestore';
import { getFirestore } from '@/firebase/server-init';
import { orders as seedOrders, users as seedUsers } from './data';

export async function seedDatabase() {
  const db = await getFirestore();
  const batch = db.batch();

  try {
    // Clear existing data
    const [ordersSnapshot, usersSnapshot, capitalSnapshot] = await Promise.all([
      db.collection('orders').get(),
      db.collection('users').get(),
      db.collection('capital').get(),
    ]);

    // Delete existing documents
    ordersSnapshot.forEach(doc => batch.delete(doc.ref));
    usersSnapshot.forEach(doc => batch.delete(doc.ref));
    capitalSnapshot.forEach(doc => batch.delete(doc.ref));

    await batch.commit();
    batch = db.batch();

    // Seed Users
    const usersCollection = db.collection('users');
    seedUsers.forEach(user => {
      const docRef = usersCollection.doc();
      batch.set(docRef, {
        ...user,
        createdAt: FieldValue.serverTimestamp(),
      });
    });

    // Seed Orders
    const ordersCollection = db.collection('orders');
    seedOrders.forEach(order => {
      const docRef = ordersCollection.doc();
      batch.set(docRef, {
        ...order,
        orderDate: Timestamp.fromDate(new Date(order.orderDate || Date.now())),
        createdAt: FieldValue.serverTimestamp(),
        updatedAt: FieldValue.serverTimestamp(),
      });
    });

    await batch.commit();
    
    return { success: true, message: 'Database seeded successfully!' };
  } catch (error) {
    console.error('Error seeding database:', error);
    return { success: false, message: 'Failed to seed database.' };
  }
}