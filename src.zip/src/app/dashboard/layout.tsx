import { Sidebar } from '@/components/dashboard/sidebar';
import { AuthenticatedHeader } from '@/components/dashboard/authenticated-header';
import { ErrorBoundary } from '@/components/error-boundary';

export default function DashboardLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1">
        <AuthenticatedHeader />
        <main className="flex-1 overflow-auto">
          <ErrorBoundary>
            {children}
          </ErrorBoundary>
        </main>
      </div>
    </div>
  );
}