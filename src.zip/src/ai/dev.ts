import { config } from 'dotenv';
config();

import '@/ai/flows/generate-dashboard-summary.ts';
