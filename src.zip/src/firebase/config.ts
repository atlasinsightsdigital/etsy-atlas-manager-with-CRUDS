
export const firebaseConfig = {
  apiKey: "AIzaSyAED3wejoEmVzg2tIevWnatd5furcDihhQ",
  authDomain: "etsy1-91f90.firebaseapp.com",
  projectId: "etsy1-91f90",
  storageBucket: "etsy1-91f90.firebasestorage.app",
  messagingSenderId: "792030638364",
  appId: "1:792030638364:web:60d1bbefebb6e923048ad9",
  measurementId: "G-QN07JM4PC4"
};