import { useState, useCallback } from 'react';
import { collection, addDoc, updateDoc, deleteDoc, doc, serverTimestamp } from 'firebase/firestore';
import { initializeFirebase } from '@/firebase';

// Add these hook functions after the existing useCollection hook

/**
 * Hook for CRUD operations on a Firestore collection
 */
export function useCollectionCRUD<T = any>(collectionName: string) {
  const { firestore } = initializeFirebase();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  const create = useCallback(async (data: Omit<T, 'id' | 'createdAt' | 'updatedAt'>): Promise<T & { id: string }> => {
    setIsLoading(true);
    setError(null);
    
    try {
      const docRef = await addDoc(collection(firestore, collectionName), {
        ...data,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      
      setIsLoading(false);
      return { id: docRef.id, ...data } as T & { id: string };
    } catch (err) {
      const error = err as Error;
      setError(error);
      setIsLoading(false);
      throw error;
    }
  }, [firestore, collectionName]);

  const update = useCallback(async (id: string, data: Partial<T>): Promise<void> => {
    setIsLoading(true);
    setError(null);
    
    try {
      const docRef = doc(firestore, collectionName, id);
      await updateDoc(docRef, {
        ...data,
        updatedAt: serverTimestamp(),
      });
      
      setIsLoading(false);
    } catch (err) {
      const error = err as Error;
      setError(error);
      setIsLoading(false);
      throw error;
    }
  }, [firestore, collectionName]);

  const remove = useCallback(async (id: string): Promise<void> => {
    setIsLoading(true);
    setError(null);
    
    try {
      const docRef = doc(firestore, collectionName, id);
      await deleteDoc(docRef);
      
      setIsLoading(false);
    } catch (err) {
      const error = err as Error;
      setError(error);
      setIsLoading(false);
      throw error;
    }
  }, [firestore, collectionName]);

  return {
    create,
    update,
    remove,
    isLoading,
    error,
  };
}