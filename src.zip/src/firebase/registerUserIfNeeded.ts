// src/firebase/registerUserIfNeeded.ts
import { getFirestore } from "@/firebase/server-init"; // your server-init exported getFirestore
import { doc, getDoc, setDoc, serverTimestamp } from "firebase-admin/firestore";

export async function registerUserIfNeeded(uid: string, payload?: {
  email?: string;
  displayName?: string | null;
  photoURL?: string | null;
}) {
  if (!uid) throw new Error("registerUserIfNeeded: missing uid");

  const db = await getFirestore();
  const userRef = doc(db, "users", uid);
  const snap = await getDoc(userRef);

  if (snap.exists()) {
    return { created: false, uid };
  }

  const now = serverTimestamp();
  const userDoc = {
    uid,
    email: payload?.email || null,
    displayName: payload?.displayName || null,
    photoURL: payload?.photoURL || null,
    role: "user", // default role
    createdAt: now,
    updatedAt: now,
  };

  await setDoc(userRef, userDoc);
  return { created: true, uid };
}
